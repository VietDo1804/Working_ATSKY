#ifndef MCU_H_
#define MCU_H_

#include "stm32l4xx_ll_system.h"

int mcu_init(void);

#endif /* MCU_H_ */
