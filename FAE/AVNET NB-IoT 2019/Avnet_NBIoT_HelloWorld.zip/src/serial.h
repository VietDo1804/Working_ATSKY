#ifndef _SERIAL_H_
#define _SERIAL_H_

int serial_init(void);
int serial_deinit(void);
int serial_send(const char *buf, unsigned int size);
void serial_modem_pwrst(void);

#endif /* #ifndef _SERIAL_H_ */
