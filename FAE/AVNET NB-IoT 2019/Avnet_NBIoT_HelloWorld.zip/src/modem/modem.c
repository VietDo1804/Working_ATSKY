#include <stdio.h>   /* Standard input/output definitions */
#include <stdlib.h>
#include <string.h>  /* String function definitions */
#include <inttypes.h>

#include "log.h"
#include "sys_tick.h"
#include "serial.h"
#include "modem.h"

#define AT_BUFFER_SIZE			512

md_resp_t md_resp;
md_urc_t  md_urc;
modem_status_t md_st;

#define MSG_NORMAL					0	// Normal at response which end by <CR><LF>
#define MSG_URC						1	// Unsolicited Result Code
#define MSG_BINARY					2	// Binary data
static int msgtype = MSG_NORMAL;

char atbuf[AT_BUFFER_SIZE];
unsigned int atid = 0;

volatile bool sock_error_urc;

packet_t nwkpack;

/*************************************************************************
 * URC handler
 *************************************************************************/
void urc_handler(md_urc_t *urc)
{
    if(urc == NULL)
        return;

    if(strncmp(urc->buf, "+CEREG:", 7) == 0)    // This is modem response to "AT+CEREG?" command
    {
        if(urc->buf[10] == '1' || urc->buf[10] == '5')
        {
            md_st.eps_registered = 1;   // eps registered
        }
        else
        {
            md_st.eps_registered = 0;   // eps not registered
        }
        md_urc.new = false;     // already processed
        return;
    }

    if(strncmp(urc->buf, "+QIOPEN:", 8) == 0)
    {
        if(urc->buf[11] == '0')  // no error
        {
            urc->buf[10] = 0;
            md_st.opened_socket = atoi(&(urc->buf[9]));
            md_urc.new = false;     // already processed
            return;            
        }
    }
    
    if(strncmp(urc->buf, "+QIURC: \"recv\"", 14) == 0)
    {
        char *cp;
        
        cp = strtok(urc->buf, ",");
        if(cp)
        {
            cp = strtok(NULL, ",");
            if(cp)
            {
                md_st.rcv_sock = atoi(cp);
                md_st.rcv_numbyte = 255;    // Don't care
            }
        }
        md_urc.new = false;     // already processed
        return;
    }
    
    if(strncmp(urc->buf, "+IP:", 4) == 0)
    {
        memset(md_st.ip, 0, 16);
        urc->buf[urc->len - 1] = 0; // null terminate
        memcpy(md_st.ip, &(urc->buf[5]), 15);
        md_urc.new = false;     // already processed
        return;
    }
    
    if(strncmp(urc->buf, "+CGDCONT:", 9) == 0)
    {
        char *cp;
        
        cp = strtok(urc->buf, "\"");
        if(cp)
        {
            cp = strtok(NULL, "\"");
            if(cp)
            {
                memset(md_st.pdp_type, 0, 8);
                strcpy(md_st.pdp_type, cp);
                cp = strtok(NULL, "\"");
                if(cp)
                {
                    cp = strtok(NULL, "\"");
                    if(cp)
                    {
                        memset(md_st.apn, 0, 16);
                        strcpy(md_st.apn, cp);
                    }
                }
            }
        }
        md_urc.new = false;     // already processed
        return;
    }    
    
    if(strncmp(urc->buf, "+CGSN:", 6) == 0)
    {
        memset(md_st.imei, 0, 16);
        memcpy(md_st.imei, &(urc->buf[7]), 15);
        md_urc.new = false;     // already processed
        return;
    }
    
    if(strncmp(urc->buf, "+QNTP:", 6) == 0)
    {
        struct tm t;
        char *cp;
                    
        urc->buf[urc->len] = 0;
                    
        //
        // Convert time string to time_t
        //
                    
        cp = strtok(urc->buf, "\"");
        if(cp){
            cp = strtok(NULL, "/");
            if(cp){
                t.tm_year = atoi(cp) + 2000 - 1900;
                cp = strtok(NULL, "/");
                if(cp){
                    t.tm_mon = atoi(cp) - 1;
                    cp = strtok(NULL, ",");
                    if(cp){
                        t.tm_mday = atoi(cp);
                        cp = strtok(NULL, ":");
                        if(cp){
                            t.tm_hour = atoi(cp);
                            cp = strtok(NULL, ":");
                            if(cp){
                                t.tm_min = atoi(cp);
                                cp = strtok(NULL, "+-");
                                if(cp){
                                    t.tm_sec = atoi(cp);
                                    //timeinfo.tm_isdst = -1;
                                    md_st.ntptime = mktime(&t);
                                }
                            }
                        }
                    }
                }
            }
        }
        md_urc.new = false;     // already processed
        return;
    }
}
 

/*************************************************************************
 * <CR><LF>OK<CR><LF>
 * <CR> = '\r' = 13 = 0x0D
 * <LF> = '\n' = 10 = 0x0A
 *************************************************************************/
void modem_isr(unsigned char c)
{
	switch(msgtype){

	case MSG_NORMAL:

		if(atid == 0)
		{
			if(c == '\r' || c == '\n')	// ignore leading '\r' and '\n'
				return;

			if(c == '+')
			{
				md_urc.new = false;		// this is a URC, invalidate old urc if any
				atbuf[atid++] = c;
				msgtype = MSG_URC;
				return;
			}
		}

		if(c == '\n')
		{
			////if(md_resp.new == false)	// Overwrite only when previous response has been processed
			{
				md_resp.len = atid;
				memcpy(md_resp.buf, atbuf, atid);
				md_resp.new = true;
			}
			atid = 0;		// ready for next line
		}
		else
		{
			atbuf[atid++] = c;
			if(atid >= AT_BUFFER_SIZE)
			{
				atid = 0;
				PLOG("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!AT buffer overflow");
			}
		}
		break;

	case MSG_URC:
		if(c == '\n')
		{
            ////if(md_urc.new == false)	// Overwrite only when previous URC has been processed
            {
                md_urc.len = atid;
                memcpy(md_urc.buf, atbuf, atid);
                md_urc.new = true;
                urc_handler(&(md_urc));
            }
            
			atid = 0;		// ready for next line
			msgtype = MSG_NORMAL;
		}
		else
		{
			atbuf[atid++] = c;
			if(atid >= AT_BUFFER_SIZE)
			{
				atid = 0;
				PLOG("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!AT buffer overflow");
			}
		}
		break;

	case MSG_BINARY:
		break;

	default:
		break;
	}
}

/*************************************************************************
 *
 *************************************************************************/
int modem_init(char *apn)
{
    unsigned int nwk_registered = 0;
    
    PLOG("Enter");
    
    memset(&md_st, 0, sizeof(modem_status_t));
    md_st.opened_socket = (char)(-1);   // not opened 
    md_st.rcv_sock = (char)(-1);

	if(bc66_init(apn) < 0)
	{
		return -1;
	}

    modem_get_imei();

    PLOG("Waiting for EPS registration...\r\n");
    while(!md_st.eps_registered)
    {
        modem_check_nwk_registered(&nwk_registered);
        msleep(1000);
    }
    
    modem_get_pdp_context();
    
    PLOG("Exit");
    return 0;
}

int modem_deinit(void)
{
	bc66_deinit();
	return 0;
}

int modem_get_imei(void)
{
    return bc66_cgsn();
}

int modem_check_nwk_registered(unsigned int *nwk_registd)
{
    return bc66_cereg(nwk_registd);
}

int modem_get_pdp_context(void)
{
    return bc66_get_cgdcont();
}

int modem_open_tcp_socket(int sockid, char *rhost, unsigned short rport, unsigned short lport)
{
	if(md_st.eps_registered)
	{
        return bc66_qiopen(sockid, rhost, rport, lport);
	}

    PLOG("ERROR: EPS network not registered");
	return -1;
}

int modem_close_socket(int sock)
{
    bc66_qiclose(sock);
    md_st.opened_socket = (char)(-1);   // Assume the command is always success
    return 0;
}

int modem_tcp_send(int sock, unsigned int length, char *data)
{
    if(md_st.eps_registered)
    {
        if(bc66_qisendex(sock, length, data) < 0)
        {
            PLOG("Sending error");
            return -1;
        }
        return 0;
    }
    
    PLOG("EPS network not yet registered");
    return -1;
}

int modem_tcp_receive(packet_t *nwkpack)
{
    return bc66_qird(nwkpack);
}

int modem_http_send(char *rhost, short rport, char *buf, unsigned int len)
{
    int sockid = 0;
    unsigned int count;
    
    if(md_st.opened_socket != (char)(-1))
    {
        PLOG("ERROR: A pending socket is already opened: %d", md_st.opened_socket);
        return -1;
    }
    
    if(modem_open_tcp_socket(sockid, rhost, rport, 5678) < 0)
    {
        PLOG("Error: opening tcp socket");
        return -1;
    }
    
    // Wait for socket to be opened
    PLOG("Waiting for socket %d to be opened", sockid);
    
    sock_error_urc = false;
    count = 12000;
    do {
        modem_tick();
        if(md_st.opened_socket == sockid)
        {
            PLOG("socket %d opened successfully", md_st.opened_socket);
            break;
        }
        else if(sock_error_urc)
        {
            PLOG("ERROR: open socket URC error");
            modem_close_socket(sockid);
            return -1;
        }
        msleep(10);
    } while(--count);
    
    if(md_st.opened_socket == sockid)
    {
        if(modem_tcp_send(sockid, len, buf) < 0)
        {
            PLOG("Error: tcp send");
            return -1;
        }
        return 0;
    }
    else
    {
        PLOG("Error: open socket timeout, close the socket");
        bc66_qistate(); // get socket status for debugging
        modem_close_socket(sockid);
        return -1;
    }
}

void modem_tick(void)
{
    if(md_st.rcv_numbyte)
    {
        nwkpack.new = false;
        nwkpack.sock = md_st.rcv_sock;
        modem_tcp_receive(&nwkpack);    // retrieve out the data
        md_st.rcv_numbyte = 0;          // indicate data already retrieve
    }
    
    if(md_urc.new == true)
    {
        md_urc.new = false;             // already processed
        
        if(strncmp(md_urc.buf, "+QIURC: \"closed\"", 16) == 0)
        {
            int closed_sock;
            closed_sock = atoi(&(md_urc.buf[17]));
            modem_close_socket(closed_sock);
            return;
        }
        
        if(strncmp(md_urc.buf, "+QIOPEN:", 8) == 0) // There's socket open error
        {
            sock_error_urc = true;
            md_urc.buf[md_urc.len] = 0;
            PLOG("ERROR: open socket urc: %s", md_urc.buf);
            return;
        }         
    }
}

