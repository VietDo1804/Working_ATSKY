#ifndef _BC66_H
#define _BC66_H

#include <stdbool.h>
#include <time.h>
#include <modem.h>

int bc66_init(char *apn);
int bc66_deinit(void);
int bc66_qrst(void);
int bc66_ate_off(void);
int bc66_cmee_off(void);
int bc66_disable_autosleep(void);
int bc66_ati(void);
int bc66_get_cgdcont(void);
int bc66_epsnwk_urc(bool enable_urc);
int bc66_cereg(unsigned int *registd);
int bc66_cgsn(void);
int bc66_cpsms(bool mode);
int bc66_ipr(void);
int bc66_atw(void);
    
int bc66_qicfg(void);
int bc66_qiopen(int sockid, char *rhost, unsigned short rport, unsigned short lport);
int bc66_qiclose(int sockid);
int bc66_qistate(void);
int bc66_qisendex(int sock, unsigned int length, char *buf);
int bc66_qird(packet_t *nwkpack);
int bc66_qntp(char *ntphost, char *ntpport);
    
#endif /* #ifndef _BC66_H */

