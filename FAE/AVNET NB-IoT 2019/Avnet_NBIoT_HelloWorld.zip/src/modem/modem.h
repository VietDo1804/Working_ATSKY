#ifndef MODEM_H_
#define MODEM_H_

#include <stdbool.h>
#include <time.h>

#define MD_RESP_BUFFER_SIZE		128
#define MD_URC_BUFFER_SIZE		512

typedef struct {
    char eps_registered;
    char imei[16];
    char ip[16];
    char pdp_type[8];
    char apn[16];
    char opened_socket; // currently opened socket
    char rcv_sock;      // socket that has data pending for retrieving
    char rcv_numbyte;   // number of bytes avail for reading from "rec_sock", 0 or positive num
    int rssi;
    time_t ntptime;
} modem_status_t;


typedef struct {
	char buf[MD_RESP_BUFFER_SIZE];
	unsigned int len;
	volatile bool new;				// new response line available
} md_resp_t;

typedef struct {
	char buf[MD_URC_BUFFER_SIZE];
	unsigned int len;
	volatile bool new;				// new noti line available
} md_urc_t;

typedef struct {
    unsigned char host[40];			// Null terminated string eg: "8888:8888:8888:8888:8888:8888:8888:8888"
    unsigned char port[6];			// Null terminated string eg: "65535"
    unsigned short sock;
    unsigned char buf[256];
    unsigned int len;
    bool new;
}packet_t;

extern md_resp_t md_resp;
extern md_urc_t md_urc;
extern packet_t nwkpack;

int modem_init(char *apn);
int modem_deinit(void);
int modem_get_imei(void);
int modem_check_nwk_registered(unsigned int *registd);
int modem_get_pdp_context(void);
int modem_open_tcp_socket(int sockid, char *rhost, unsigned short rport, unsigned short lport);
int modem_close_socket(int sockid);
int modem_tcp_send(int sock, unsigned int length, char *data);
int modem_tcp_receive(packet_t *nwkpack);
int modem_http_send(char *rhost, short rport, char *buf, unsigned int len);
void modem_tick(void);

#include "bc66.h"

#endif /* MODEM_H_ */

