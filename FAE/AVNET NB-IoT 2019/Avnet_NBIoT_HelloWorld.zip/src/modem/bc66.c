#include <stdio.h>   /* Standard input/output definitions */
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>  /* String function definitions */
#include <inttypes.h>

#include "log.h"
#include "sys_tick.h"
#include "modem.h"
#include "serial.h"
#include "bc66.h"

extern modem_status_t md_st;

const char htable[16] = {'0', '1', '2','3','4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F'};

static char cmdbuf[64];

/**************************************************************************************
 * wait for modem response
 * timeout = multiple of 10ms
 */
static int bc66_wait_response(unsigned int timeout)
{
    do {
        if(md_resp.new)
        {
            return 1;       // received something
        }
        msleep(10);
    } while(--timeout);
    
    return 0;
}

/**************************************************************************************
 * wake up bc66
 */
static int bc66_wakeup(void)
{
    static const char cmd_at[] = "AT\r\n";
    unsigned int retry = 5;
    
    do {
        md_resp.new = false;
        if(serial_send(cmd_at, sizeof(cmd_at)) < 0) 
        {
            return -1;
        }
        if(bc66_wait_response(5))   // wait for response for 50ms
        {
            if(strncmp(md_resp.buf, "OK", 2) == 0)
            {
                return 0; // bc66 is waken up
            }        
        }        
    } while (--retry);
    
    PLOG("ERROR: BC66 cannot wake up");
    return -1;
}


/**************************************************************************************
 * Soft reset modem
 */
int bc66_qrst(void)
{
    static const char cmd[] = "AT+QRST=1\r\n";
    
    PLOG("TX: %s", cmd);
    
	if(serial_send(cmd, sizeof(cmd)) < 0) 
	{
		return -1;
	}
    msleep(3000);    
    
    return 0;
}

/**************************************************************************************
 * Echo off
 * Must be the first command to send after powered up the modem
 */
int bc66_ate_off(void)
{
    static const char cmd_at[] = "AT\r\n";
	static const char cmd[] = "ATE0\r\n";

	PLOG("TX: %s", cmd);
    
	if(serial_send(cmd_at, sizeof(cmd_at)) < 0) 
	{
		return -1;
	}
    msleep(100);
    
	if(serial_send(cmd_at, sizeof(cmd_at)) < 0) 
	{
		return -1;
	}
    msleep(100);    
    
    md_resp.new = false;
	if(serial_send(cmd, sizeof(cmd)) < 0) 
	{
		return -1;
	}
    msleep(300);
    
    if(bc66_wait_response(50)) // if got a response within 500ms
    {
        if(strncmp(md_resp.buf, "OK", 2) == 0) // if "OK"
        {
            PLOG("ECHO off");
            return 0;
        }
    }        

    PLOG("ERROR: no response");
    return -1;
}

/**************************************************************************************
 * CMEE off
 */
int bc66_cmee_off(void)
{
	static const char cmd[] = "AT+CMEE=1\r\n";	// AT error response will be "ERROR", instead of "+CME ERROR: <err>"

	PLOG("TX: %s", cmd);

    if(bc66_wakeup() < 0)
    {
        return -1;
    }    
    
	md_resp.new = false;
	if(serial_send(cmd, sizeof(cmd)) < 0)
	{
		return -1;
	}

    if(bc66_wait_response(50)) // if got a response within 500ms
    {
        if(strncmp(md_resp.buf, "OK", 2) == 0) // if "OK"
        {
            return 0;
        }
    }            
    
    PLOG("ERROR: no response");
    return -1;
}

/**************************************************************************************
 * Disable auto sleep
 */ 
int bc66_disable_autosleep(void)
{
    static const char cmd[] = "AT+SM=UNLOCK\r\n";
    
	PLOG("TX: %s", cmd);

    if(bc66_wakeup() < 0)
    {
        return -1;
    }    

	md_resp.new = false;
	if(serial_send(cmd, sizeof(cmd)) < 0)
	{
		return -1;
	}
    
    if(bc66_wait_response(50)) // if got a response within 500ms
    {
        if(strncmp(md_resp.buf, "OK", 2) == 0) // if "OK"
        {
            PLOG("Autosleep disabled");
            return 0;
        }
    }

    PLOG("ERROR: no response");
    return -1;    
}

/**************************************************************************************
 * Print product info
 */ 
int bc66_ati(void)
{
    static const char cmd[] = "ATI\r\n";
    
	PLOG("TX: %s", cmd);

    if(bc66_wakeup() < 0)
    {
        return -1;
    }    

	md_resp.new = false;
	if(serial_send(cmd, sizeof(cmd)) < 0)
	{
		return -1;
	}
    
    msleep(100);                 // Purposely discard the response and wait for OK
    
    if(bc66_wait_response(50)) // if got a response within 500ms
    {
        if(strncmp(md_resp.buf, "OK", 2) == 0) // if "OK"
        {
            PLOG("ATI success");
            return 0;
        }
    }

    PLOG("ERROR: no response");
    return -1;        
}

/**************************************************************************************
 * Get PDP context
 */ 
int bc66_get_cgdcont(void)
{
	static const char cmd[] = "AT+CGDCONT?\r\n";

	PLOG("TX: %s", cmd);

    if(bc66_wakeup() < 0)
    {
        return -1;
    }    
    
	md_resp.new = false;
	if(serial_send(cmd, sizeof(cmd)) < 0)
	{
		return -1;
	}
    
    if(bc66_wait_response(50)) // if got a response within 500ms
    {
        if(strncmp(md_resp.buf, "OK", 2) == 0) // if "OK"
        {
            PLOG("PDP Type: %s", md_st.pdp_type);
            PLOG("APN: %s", md_st.apn);
            return 0;
        }
    }

    PLOG("ERROR: no response");
    return -1;    
}

/**************************************************************************************
 * Enable / Disable network registration URC
 */ 
int bc66_epsnwk_urc(bool enable_urc)
{
    PLOG("Enter");
    
    if(bc66_wakeup() < 0)
    {
        return -1;
    }        
    
	memset(cmdbuf, 0, 64);
	if(enable_urc)
	{
		snprintf(cmdbuf, 64, "AT+CEREG=%d\r\n", 4);
	}
	else
	{
		snprintf(cmdbuf, 64, "AT+CEREG=%d\r\n", 0);
	}
    PLOG("TX: %s", cmdbuf);
    
	md_resp.new = false;
	if(serial_send(cmdbuf, strlen(cmdbuf)) < 0)
	{
		return -1;
	}

    if(bc66_wait_response(50)) // if got a response within 500ms
    {
        if(strncmp(md_resp.buf, "OK", 2) == 0) // if "OK"
        {
            return 0;
        }
    }

    PLOG("ERROR: no response");
    return -1;        
}

/**************************************************************************************
 * Check network registration status
 */
int bc66_cereg(unsigned int *registd)
{
    static const char cmd[] = "AT+CEREG?\r\n";
    
    PLOG("Enter");
    
    if(bc66_wakeup() < 0)
    {
        return -1;
    }        
    
	md_resp.new = false;
	if(serial_send(cmd, strlen(cmd)) < 0)
	{
		return -1;
	}

    if(bc66_wait_response(50)) // if got a response within 500ms
    {
        if(strncmp(md_resp.buf, "OK", 2) == 0) // if "OK"
        {
            PLOG("EPS registered: %d", md_st.eps_registered);
            return 0;
        }
    }

    PLOG("ERROR: no response");
    return -1;       
}

/**************************************************************************************
 * Get the IMEI
 */ 
int bc66_cgsn(void)
{
    static const char cmd[] = "AT+CGSN=1\r\n";
   
    PLOG("TX: %s", cmd);
    
    if(bc66_wakeup() < 0)
    {
        return -1;
    }    
    
	md_resp.new = false;
	if(serial_send(cmd, strlen(cmd)) < 0)
	{
		return -1;
	}
    
    if(bc66_wait_response(50)) // if got a response within 500ms
    {
        if(strncmp(md_resp.buf, "OK", 2) == 0) // if "OK"
        {
            return 0;
        }
    }

    PLOG("ERROR: no response");
    return -1;            
}

/**************************************************************************************
 * Enable/Disable PSM mode
 * mode 0 -> Disable PSM
 *      1 -> Enable PSM
 *      2 -> Disable PSM, and discard all PSM parameter or reset to default if available
 */
int bc66_cpsms(bool mode)
{
	memset(cmdbuf, 0, 64);
    snprintf(cmdbuf, 64, "AT+CPSMS=%d\r\n", mode);
    
    PLOG("TX: %s", cmdbuf);
    
    if(bc66_wakeup() < 0)
    {
        return -1;
    }    
    
	md_resp.new = false;
	if(serial_send(cmdbuf, strlen(cmdbuf)) < 0)
	{
		return -1;
	}

    if(bc66_wait_response(50)) // if got a response within 500ms
    {
        if(strncmp(md_resp.buf, "OK", 2) == 0) // if "OK"
        {
            PLOG("PSM mode set to %d", mode);
            return 0;
        }
    }

    PLOG("ERROR: no response");
    return -1;    
}

/**************************************************************************************
 * Set default UART baudrate to 9600
 */
int bc66_ipr(void)
{
    static const char cmd[] = "AT+IPR=9600\r\n";
    
    PLOG("TX: %s", cmd);
    
    if(bc66_wakeup() < 0)
    {
        return -1;
    }    
    
	md_resp.new = false;
	if(serial_send(cmd, strlen(cmd)) < 0)
	{
		return -1;
	}
    
    if(bc66_wait_response(50)) // if got a response within 500ms
    {
        if(strncmp(md_resp.buf, "OK", 2) == 0) // if "OK"
        {
            PLOG("Default baud rate=9600");
            return 0;
        }
    }

    PLOG("ERROR: no response");
    return -1;            
}

/**************************************************************************************
 * Store user settings to user profile 0
 */
int bc66_atw(void)
{
    static const char cmd[] = "AT&W0\r\n";
    
    PLOG("TX: %s", cmd);
    
    if(bc66_wakeup() < 0)
    {
        return -1;
    }    
    
	md_resp.new = false;
	if(serial_send(cmd, strlen(cmd)) < 0)
	{
		return -1;
	}
    
    if(bc66_wait_response(500)) // if got a response within 500ms
    {
        if(strncmp(md_resp.buf, "OK", 2) == 0) // if "OK"
        {
            PLOG("Success");
            return 0;
        }
    }

    PLOG("ERROR: no response");
    return -1;            
}

/**************************************************************************************
 * Store user settings to user profile 0
 */
int bc66_qcgdefcont(char *apn)
{
	memset(cmdbuf, 0, 64);
    
    if(*apn)
    {
        snprintf(cmdbuf, 64, "AT+QCGDEFCONT=\"IP\",%s,\"\",\"\"\r\n", apn);
    }
    else
    {
        snprintf(cmdbuf, 64, "AT+QCGDEFCONT=\"IP\",\"\",\"\",\"\"\r\n");
    }
    
    PLOG("TX: %s", cmdbuf);
    
    if(bc66_wakeup() < 0)
    {
        return -1;
    }    
    
	md_resp.new = false;
	if(serial_send(cmdbuf, strlen(cmdbuf)) < 0)
	{
		return -1;
	}
    
    if(bc66_wait_response(500)) // if got a response within 500ms
    {
        if(strncmp(md_resp.buf, "OK", 2) == 0) // if "OK"
        {
            PLOG("Success");
            return 0;
        }
    }

    PLOG("ERROR: no response");
    return -1;            
}


/**************************************************************************************
 * Configure TCP/IP config parameters
 * <recv_data_format> = 1 (hex mode)
 * <view mode> = 1 (data header, data)
 * <show_length_mode> = 1 (show optional length in buffer access mode
 */
int bc66_qicfg(void)
{
    PLOG("Enter");
    
    static const char cmd1[] = "AT+QICFG=\"dataformat\",1,1\r\n";
    static const char cmd2[] = "AT+QICFG=\"viewmode\",1\r\n";
    static const char cmd3[] = "AT+QICFG=\"showlength\",1\r\n";
    
    if(bc66_wakeup() < 0)
    {
        return -1;
    }        
    
	md_resp.new = false;
	if(serial_send(cmd1, strlen(cmd1)) < 0)
	{
		return -1;
	}
    
    if(bc66_wait_response(50)) // if got a response within 500ms
    {
        if(strncmp(md_resp.buf, "OK", 2)) // if not "OK"
        {
            PLOG("ERROR");
            return -1;
        }
    }

	md_resp.new = false;
	if(serial_send(cmd2, strlen(cmd2)) < 0)
	{
		return -1;
	}
    
    if(bc66_wait_response(50)) // if got a response within 500ms
    {
        if(strncmp(md_resp.buf, "OK", 2)) // if not "OK"
        {
            PLOG("ERROR");
            return -1;
        }
    }    
    
	md_resp.new = false;
	if(serial_send(cmd3, strlen(cmd3)) < 0)
	{
		return -1;
	}
    
    if(bc66_wait_response(50)) // if got a response within 500ms
    {
        if(strncmp(md_resp.buf, "OK", 2)) // if not "OK"
        {
            PLOG("ERROR");
            return -1;
        }
    }    
    
    PLOG("OK");
    return 0;
}


/**************************************************************************************
 * Open a socket
 * contextID=1, IPV4, Buffer Access mode
 * sockid = BC66's connectID
 */
int bc66_qiopen(int sockid, char *rhost, unsigned short rport, unsigned short lport)
{
    static const char cmd_get_err[] = "AT+QIGETERROR\r\n";
    
    PLOG("Enter");
    
    if(sockid > 4 || sockid < 0)
    {
        PLOG("Invalid socket id");
        return -1;
    }
    
	memset(cmdbuf, 0, 64);
    snprintf(cmdbuf, 64, "AT+QIOPEN=1,%d,\"TCP\",\"%s\",%d,%d,0,0\r\n", sockid, rhost, rport, lport);
    
    PLOG("TX: %s", cmdbuf);
    
    if(bc66_wakeup() < 0)
    {
        return -1;
    }    
    
	md_resp.new = false;
	if(serial_send(cmdbuf, strlen(cmdbuf)) < 0)
	{
		return -1;
	}

    if(bc66_wait_response(6000)) // if got a response within 60sec
    {
        if(strncmp(md_resp.buf, "OK", 2) == 0) // if "OK"
        {
            PLOG("Socket %d opening in process...", sockid);
            return 0;
        }
        else
        {
            PLOG("ERROR: ERROR opening socket, retrieving error code...");
            if(bc66_wakeup() < 0)
            {
                return -1;
            }        
    
            md_resp.new = false;
            if(serial_send(cmd_get_err, strlen(cmd_get_err)) < 0)
            {
                return -1;
            }            
            msleep(1000);
            return -1;
        }
    }
    
    PLOG("ERROR: No response within 60 sec per datasheet, hang!!!");
    while(1);
 }

/**************************************************************************************
 * Close a socket
 * sockid = BC66's connectID
 */
int bc66_qiclose(int sockid)
{
    PLOG("Enter, sockid=%d", sockid);
    
    if(sockid > 4 || sockid < 0)
    {
        PLOG("Invalid socket id");
        return -1;
    }
    
	memset(cmdbuf, 0, 64);
    snprintf(cmdbuf, 64, "AT+QICLOSE=%d\r\n", sockid);
    
    PLOG("TX: %s", cmdbuf);
    
    if(bc66_wakeup() < 0)
    {
        return -1;
    }    
    
	md_resp.new = false;
	if(serial_send(cmdbuf, strlen(cmdbuf)) < 0)
	{
		return -1;
	}
    //md_st.opened_socket = (char)(-1);   // Assume the command is always success
    
    if(bc66_wait_response(30))  // if got a response within 300ms
    {
        md_resp.new = false;
        if(strncmp(md_resp.buf, "OK", 2) == 0) // if "OK"
        {
            if(bc66_wait_response(50)) // if got a response within 500ms
            {
                if(strncmp(md_resp.buf, "CLOSE OK", 2) == 0)
                {
                    PLOG("CLOSE OK");
                    return 0;
                }
            }

        }
    }

    PLOG("ERROR: no response");
    return -1;
}


/**************************************************************************************
 * Sending through socket, given the socket number
 */
int bc66_qistate(void)
{
    PLOG("Enter");
    
    static const char cmd[] = "AT+QISTATE?\r\n";
    
    if(bc66_wakeup() < 0)
    {
        return -1;
    }        
    
	md_resp.new = false;
	if(serial_send(cmd, strlen(cmd)) < 0)
	{
		return -1;
	}
    msleep(100);
    
    return 0;
}


/**************************************************************************************
 * Sending through socket, given the socket number
 */
int bc66_qisendex(int sock, unsigned int length, char *buf)
{
    unsigned int i;
    char c;
    
    PLOG("Enter");
    
    if(sock != md_st.opened_socket)
    {
        PLOG("ERROR: socket is not opened, md_st.opened_socket=%d, sock=%d", md_st.opened_socket, sock);
        return -1;
    }
    
	memset(cmdbuf, 0, 64);
    snprintf(cmdbuf, 64, "AT+QISENDEX=%d,%d,", sock, length);
    
    if(bc66_wakeup() < 0)
    {
        return -1;
    }    
    
	md_resp.new = false;
	if(serial_send(cmdbuf, strlen(cmdbuf)) < 0)
	{
		return -1;
	}
   
	// convert every data byte to HEX and send out
	for(i=0; i<length; i++)
	{
		c = htable[(buf[i] >> 4)];
		if(serial_send(&c, 1) < 0)
		{
			return -1;
		}
		c = htable[(buf[i] & 0x0F)];
		if(serial_send(&c, 1) < 0)
		{
			return -1;
		}
	}    
    
	memset(cmdbuf, 0, 64);
    snprintf(cmdbuf, 64, "\r\n");
	if(serial_send(cmdbuf, strlen(cmdbuf)) < 0)
	{
		return -1;
	}

    if(bc66_wait_response(30)) // if got a response within 300ms
    {
        md_resp.new = false;
        if(strncmp(md_resp.buf, "OK", 2) == 0) // if "OK"
        {
            if(bc66_wait_response(50)) // if got a response within 500ms
            {
                if(strncmp(md_resp.buf, "SEND OK", 2) == 0) // data has been queue in the modem memory
                {
                    PLOG("SEND OK");
                    return 0;
                }
            }

        }
    }

    PLOG("ERROR: SEND FAILED or no response");
    return -1;    
}

/**************************************************************************************
 * Retrieve network data
 * The data actual length is returned at buflen
 * Make sure buf must be at least 256 bytes
 */
int bc66_qird(packet_t *nwkpack)
{
    PLOG("Enter");
    
    nwkpack->len = 0;
    
	memset(cmdbuf, 0, 64);
    snprintf(cmdbuf, 64, "AT+QIRD=%d,512\r\n", nwkpack->sock);   // Ready to receive 512 bytes
    
	md_resp.new = false;
	if(serial_send(cmdbuf, strlen(cmdbuf)) < 0)
	{
		return -1;
	}    
    
    if(bc66_wait_response(200)) // if got a response within 2000ms
    {
        if(strncmp(md_resp.buf, "OK", 2) == 0) // if "OK"
        {
            if(md_urc.new)
            {
                md_urc.new = false;
                if(strncmp(md_urc.buf, "+QIRD:", 6) == 0) // 
                {
                    // Parse receive data URC
                    char *cp;
                    int dlen, rlen; // data length and remaining length
                    
                    cp = strtok(md_urc.buf, " ");
                    if(cp){ // "+QIRD:"
                        
                        cp = strtok(NULL, ",");
                        if(cp)
                        {
                            dlen = atoi((const char *)cp);
                            if(dlen == 0){
                                PLOG("Zero data length");
                                return 0;
                            }
                            
                            cp = strtok(NULL, ",");
                            if(cp)
                            {
                                rlen = atoi((const char *)cp);
                                if(rlen){
                                    PLOG("!!!!!!!!!!!!!! remaining length != 0");
                                }
                                
                                cp = strtok(NULL, ",");
                                if(cp)
                                {
                                    unsigned char h;
                                    unsigned int i;
                        
                                    for(i=0; i<dlen; i++)
                                    {
                                        if(*cp >= 'A') 
                                            h = (*cp++ - 'A' + 10) << 4;
                                        else 
                                            h = (*cp++ - '0') << 4;

                                        if(*cp >= 'A')
                                            h |= (*cp++ - 'A' + 10);
                                        else 
                                            h |= (*cp++ - '0');

                                        nwkpack->buf[i] = h;
                                    }
                                    nwkpack->len = dlen;
                                    nwkpack->new = true;
                                    PLOG("Rx new data");
                                    return 0;           // Read and parse successfully                                    
                                }
                            }
                        }
                    }
                }
            }
    
            PLOG("No receive data URC");
            return -1;
        }
    }        
    
    PLOG("ERROR: Receive FAILED or no response");
    return -1;
}

/**************************************************************************************
 * Synchronize local time with NTP
 */
int bc66_qntp(char *ntphost, char *ntpport)
{
    PLOG("Enter");
    
	memset(cmdbuf, 0, 64);
    snprintf(cmdbuf, 64, "AT+QNTP=1,\"%s\",%s,1\r\n", ntphost, ntpport);
    
    PLOG("TX: %s", cmdbuf);
    
    if(bc66_wakeup() < 0)
    {
        return -1;
    }    
    
	md_resp.new = false;
	if(serial_send(cmdbuf, strlen(cmdbuf)) < 0)
	{
		return -1;
	}

    md_urc.new = false;
    if(bc66_wait_response(50))                  // if got a response within 500ms
    {
        if(strncmp(md_resp.buf, "OK", 2) == 0)  // if "OK"
        {
            PLOG("NTP requested");
            return 0;
        }
    }

    PLOG("ERROR: no response");
    return -1;    
}


/**************************************************************************************
 * Init serial port and BC66
 */
int bc66_init(char *apn)
{
    serial_modem_pwrst();

	if(serial_init() < 0)
	{
		PLOG("ERROR: serial_init");
		return -1;
	}

	if(bc66_ate_off() < 0)
	{
		PLOG("ERROR: bc66_ate_off");
		return -1;
	}

    if(bc66_qcgdefcont(apn) < 0)
    {
        PLOG("ERROR: bc66_qcgdefcont");
        return -1;
    }    
    
	if(bc66_qrst() < 0)
	{
		PLOG("ERROR: bc66_qrst");
		return -1;
	}    
    
    if(bc66_ate_off() < 0)
	{
		PLOG("ERROR: bc66_ate_off");
		return -1;
	}
    
	if(bc66_cmee_off() < 0)
	{
		PLOG("ERROR: bc66_cmee_off");
		return -1;
	}    

    if(bc66_ati() < 0)
    {
        PLOG("ERROR: bc66_ati");
        return -1;
    }
    
	if(bc66_epsnwk_urc(false) < 0)		// disable CEREG URC
	{
		PLOG("ERROR: bc66_epsnwk_urc");
		return -1;
	}
    
    if(bc66_qicfg() < 0)
    {
		PLOG("ERROR: bc66_qicfg");
		return -1;        
    }
    
    if(bc66_cpsms(0) < 0)   // Disable PSM first
    {
		PLOG("ERROR: bc66_cpsms");
		return -1;        
    }     
    
    return 0;
}

/**************************************************************************************
 * DeInit serial port
 */
int bc66_deinit(void)
{
    serial_deinit();
    return 0;
}

