#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>

#include "mcu.h"
#include "log.h"
#include "sys_tick.h"
#include "modem.h"

#define ADS_APP_SERVER_IP       "103.60.63.174"
#define ADS_APP_SERVER_PORT     50103

//
// Set APN, or ""
// 
//
//#define APN                     "nbiot"
#define APN                     ""
#define MYDATA                  "Hello from David"

extern modem_status_t md_st;
extern packet_t nwkpack;

const char http_header[] = "POST /iotlogger/pkthandler HTTP/1.1\r\n"
                     "host: %s:%d\r\n"
                     "user-agent: ACTILITY-LRCLRN-DEVICE-AGENT/1.0\r\n"
                     "accept: /*\r\n"
                     "content-type: application/json\r\n"
                     "content-length: %d\r\n"
                     "\r\n";

const char http_template[] = "{"
                   "\"app\":\"vn-workshop-2019\","
                   "\"IMEI\":\"%s\","
                   "\"rssi\":\"%d\","
                   "\"data\":\"%s\""
                   "}";

char httpbuf[512];
char httpbody[256];

int app_http_send(void)
{
    unsigned int len, count;
    unsigned int registd;
    
    PLOG(" ");
    PLOG("<<<<<<<< ENTER >>>>>>>>>>>> ");
    PLOG("Sending HTTP request to server...");

    if(modem_check_nwk_registered(&registd) < 0)
    {
        PLOG("ERROR: checking network registration status");
        return -1;
    }
    
    if(md_st.eps_registered == 0)
    {
        PLOG("Network not registered");
        return -1;
    }
    
    //
    // Prepare the data
    //
    
    memset(httpbody, 0, sizeof(httpbody));
    sprintf(httpbody, http_template, md_st.imei, md_st.rssi, MYDATA);
    len = strlen(httpbody);
    PLOG("HTTP body length:%d", len);
    
    memset(httpbuf, 0, sizeof(httpbuf));
    sprintf(httpbuf, http_header, md_st.ip, 5678, len);
    len = strlen(httpbuf);
    
    sprintf((char *)(httpbuf + len), "%s", httpbody);
    len = strlen(httpbuf);
    PLOG("HTTP buf length:%d", len);
    printf("\r\n==== HTTP message ===============================================\r\n");
    printf("%s", httpbuf);
    printf("\r\n=================================================================\r\n\r\n");

    //
    // Send to server
    //

    if(modem_http_send(ADS_APP_SERVER_IP, ADS_APP_SERVER_PORT, httpbuf, len) < 0)
    {
        PLOG("ERROR");
        return -1;
    }

    //
    // Waiting for reply within 120 sec timeout
    //
    count = 6000;
    do {
        modem_tick();
        
        if(nwkpack.new)
        {
            nwkpack.new = false;
            
            // Inspect the server reply if you wish

            modem_close_socket(md_st.opened_socket);
            
            return 0; // success
        }
        msleep(20);
    } while(--count);

    PLOG("ERROR: no reply from server, let's close the socket anyway");
    modem_close_socket(0);
    
    return -1;
}

int main(void)
{
    char apn[] = APN;
    
	mcu_init();

    PLOG_INIT();
    PLOG("Demo Start");
    
    if(modem_init(apn) < 0)
    {
        PLOG("Failed in modem_init");
        return -1;
    }        
    
    for(;;)
    {
        app_http_send();
        msleep(20000);
    }
}

