/*
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/.
 */

#include "mcu.h"
#include "sys_tick.h"

#include <inttypes.h>
#include <math.h>
#include <stdio.h>
#include <time.h>

static volatile unsigned long counter_ms = 0;

void sys_clock_init(void)
{
}

void sys_tick_initialise(void)
{
}


uint32_t sys_tick_get_s(void)
{
    return (counter_ms/1000);
}


uint32_t sys_tick_get_ms(void)
{
    return (counter_ms % 1000);
}

void msleep(uint32_t ms)
{
    unsigned long nowtime;
    
    nowtime = counter_ms;
    
    while((counter_ms - nowtime) < ms)
    {};
}

void SysTick_Handler(void)
{
    ++counter_ms;
}
