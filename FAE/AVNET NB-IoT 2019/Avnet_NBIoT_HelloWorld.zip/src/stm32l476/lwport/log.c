#include "log.h"

#include <stdarg.h>
#include <stdio.h>
#include <string.h>
#include <stdio.h>
#include <ctype.h>

#include "stm32l4xx_ll_bus.h"
#include "stm32l4xx_ll_rcc.h"
#include "stm32l4xx_ll_system.h"
#include "stm32l4xx_ll_utils.h"
#include "stm32l4xx_ll_gpio.h"
#include "stm32l4xx_ll_exti.h"
#include "stm32l4xx_ll_usart.h"
#include "stm32l4xx_ll_pwr.h"

#include "sys_tick.h"

static void print_indent(FILE * stream, int num);

static char log_buf[256];

void pLog_Init(void)
{
    // Use USART1 for uart trace output

    //Enable the peripheral clock of GPIO Port
    LL_AHB2_GRP1_EnableClock(LL_AHB2_GRP1_PERIPH_GPIOA);

    // Configure Tx Pin (PA9) as : Alternate function, High Speed, Push pull, Pull up
    LL_GPIO_SetPinMode(GPIOA, LL_GPIO_PIN_9, LL_GPIO_MODE_ALTERNATE);
    ////LL_GPIO_SetAFPin_0_7(GPIOA, LL_GPIO_PIN_2, LL_GPIO_AF_7);
    LL_GPIO_SetAFPin_8_15(GPIOA, LL_GPIO_PIN_9, LL_GPIO_AF_7);
    LL_GPIO_SetPinSpeed(GPIOA, LL_GPIO_PIN_9, LL_GPIO_SPEED_FREQ_HIGH);
    LL_GPIO_SetPinOutputType(GPIOA, LL_GPIO_PIN_9, LL_GPIO_OUTPUT_PUSHPULL);
    LL_GPIO_SetPinPull(GPIOA, LL_GPIO_PIN_9, LL_GPIO_PULL_UP);

    // Configure Rx Pin (PA10) as : Alternate function, High Speed, Push pull, Pull up
    LL_GPIO_SetPinMode(GPIOA, LL_GPIO_PIN_10, LL_GPIO_MODE_ALTERNATE);
    ////LL_GPIO_SetAFPin_0_7(GPIOA, LL_GPIO_PIN_3, LL_GPIO_AF_7);
    LL_GPIO_SetAFPin_8_15(GPIOA, LL_GPIO_PIN_10, LL_GPIO_AF_7);
    LL_GPIO_SetPinSpeed(GPIOA, LL_GPIO_PIN_10, LL_GPIO_SPEED_FREQ_HIGH);
    LL_GPIO_SetPinOutputType(GPIOA, LL_GPIO_PIN_10, LL_GPIO_OUTPUT_PUSHPULL);
    LL_GPIO_SetPinPull(GPIOA, LL_GPIO_PIN_10, LL_GPIO_PULL_UP);

    /* (3) Enable USART peripheral clock and clock source ***********************/
    ////LL_APB1_GRP1_EnableClock(LL_APB1_GRP1_PERIPH_USART2);
    LL_APB2_GRP1_EnableClock(LL_APB2_GRP1_PERIPH_USART1);

    /* Set clock source */
    ////LL_RCC_SetUSARTClockSource(LL_RCC_USART2_CLKSOURCE_PCLK1);
    LL_RCC_SetUSARTClockSource(LL_RCC_USART1_CLKSOURCE_PCLK2);

    /* TX/RX direction, TX only */
    LL_USART_SetTransferDirection(USART1, LL_USART_DIRECTION_TX);

    /* 8 data bit, 1 start bit, 1 stop bit, no parity */
    LL_USART_ConfigCharacter(USART1, LL_USART_DATAWIDTH_8B, LL_USART_PARITY_NONE, LL_USART_STOPBITS_1);


    LL_USART_SetBaudRate(USART1, SystemCoreClock, LL_USART_OVERSAMPLING_16, 115200); 

    /* (5) Enable USART *********************************************************/
    LL_USART_Enable(USART1);

    /* Polling USART initialisation */
    ////while((!(LL_USART_IsActiveFlag_TEACK(USART2))) || (!(LL_USART_IsActiveFlag_REACK(USART2))))
    while((!(LL_USART_IsActiveFlag_TEACK(USART1))))
    { 
    }
    
    
#if 0    
    // Use USART2 for uart trace output

    //Enable the peripheral clock of GPIO Port
    LL_AHB2_GRP1_EnableClock(LL_AHB2_GRP1_PERIPH_GPIOA);

    // Configure Tx Pin (PA2) as : Alternate function, High Speed, Push pull, Pull up
    LL_GPIO_SetPinMode(GPIOA, LL_GPIO_PIN_2, LL_GPIO_MODE_ALTERNATE);
    LL_GPIO_SetAFPin_0_7(GPIOA, LL_GPIO_PIN_2, LL_GPIO_AF_7);
    LL_GPIO_SetPinSpeed(GPIOA, LL_GPIO_PIN_2, LL_GPIO_SPEED_FREQ_HIGH);
    LL_GPIO_SetPinOutputType(GPIOA, LL_GPIO_PIN_2, LL_GPIO_OUTPUT_PUSHPULL);
    LL_GPIO_SetPinPull(GPIOA, LL_GPIO_PIN_2, LL_GPIO_PULL_UP);

    // Configure Rx Pin (PA3) as : Alternate function, High Speed, Push pull, Pull up
    LL_GPIO_SetPinMode(GPIOA, LL_GPIO_PIN_3, LL_GPIO_MODE_ALTERNATE);
    LL_GPIO_SetAFPin_0_7(GPIOA, LL_GPIO_PIN_3, LL_GPIO_AF_7);
    LL_GPIO_SetPinSpeed(GPIOA, LL_GPIO_PIN_3, LL_GPIO_SPEED_FREQ_HIGH);
    LL_GPIO_SetPinOutputType(GPIOA, LL_GPIO_PIN_3, LL_GPIO_OUTPUT_PUSHPULL);
    LL_GPIO_SetPinPull(GPIOA, LL_GPIO_PIN_3, LL_GPIO_PULL_UP);

    /* (2) NVIC Configuration for USART interrupts */
    /*  - Set priority for USARTx_IRQn */
    /*  - Enable USARTx_IRQn */
    ////NVIC_SetPriority(USARTx_IRQn, 0);  
    ////NVIC_EnableIRQ(USARTx_IRQn);

    /* (3) Enable USART peripheral clock and clock source ***********************/
    LL_APB1_GRP1_EnableClock(LL_APB1_GRP1_PERIPH_USART2);

    /* Set clock source */
    LL_RCC_SetUSARTClockSource(LL_RCC_USART2_CLKSOURCE_PCLK1);

    /* (4) Configure USART functional parameters ********************************/
  
    /* Disable USART prior modifying configuration registers */
    /* Note: Commented as corresponding to Reset value */
    // LL_USART_Disable(USARTx_INSTANCE);

    /* TX/RX direction, TX only */
    LL_USART_SetTransferDirection(USART2, LL_USART_DIRECTION_TX);

    /* 8 data bit, 1 start bit, 1 stop bit, no parity */
    LL_USART_ConfigCharacter(USART2, LL_USART_DATAWIDTH_8B, LL_USART_PARITY_NONE, LL_USART_STOPBITS_1);

    /* No Hardware Flow control */
    /* Reset value is LL_USART_HWCONTROL_NONE */
    // LL_USART_SetHWFlowCtrl(USARTx_INSTANCE, LL_USART_HWCONTROL_NONE);

    /* Oversampling by 16 */
    /* Reset value is LL_USART_OVERSAMPLING_16 */
    //LL_USART_SetOverSampling(USARTx_INSTANCE, LL_USART_OVERSAMPLING_16);

    /* Set Baudrate to 115200 using APB frequency set to 80000000 Hz */
    /* Frequency available for USART peripheral can also be calculated through LL RCC macro */
    /* Ex :
      Periphclk = LL_RCC_GetUSARTClockFreq(Instance); or LL_RCC_GetUARTClockFreq(Instance); depending on USART/UART instance
  
      In this example, Peripheral Clock is expected to be equal to 80000000 Hz => equal to SystemCoreClock
    */
    LL_USART_SetBaudRate(USART2, SystemCoreClock, LL_USART_OVERSAMPLING_16, 115200); 

    /* (5) Enable USART *********************************************************/
    LL_USART_Enable(USART2);

    /* Polling USART initialisation */
    ////while((!(LL_USART_IsActiveFlag_TEACK(USART2))) || (!(LL_USART_IsActiveFlag_REACK(USART2))))
    while((!(LL_USART_IsActiveFlag_TEACK(USART2))))
    { 
    }

    /* Enable RXNE and Error interrupts */
    ////LL_USART_EnableIT_RXNE(USARTx_INSTANCE);
    ////LL_USART_EnableIT_ERROR(USARTx_INSTANCE);    
#endif    
}

//
// Print Log
//
void pLog(const char *funcstr, const char *format, ...)
{
	int result = 0;
	int pos;
	char *p;

	memset(log_buf, 0x20, 256);
	log_buf[255] = 0;

	pos = snprintf(log_buf, sizeof(log_buf), "[%08ld.%03ld : ", (long)sys_tick_get_s(), (long)sys_tick_get_ms());

	strcat(log_buf, funcstr);
	pos += strlen(funcstr);
	log_buf[pos] = ' ';
	log_buf[54] = ']';
	log_buf[55] = ' ';

	pos = 56;
	va_list list;
	va_start(list, format);
	result = vsnprintf(&log_buf[pos], sizeof(log_buf) - pos - 1, format, list);
	log_buf[sizeof(log_buf) - 1] = 0;
	va_end(list);
	if (result < 0)
	{
		return;
	}

	p = log_buf;
	while (*p != '\0')
	{
		putchar(*p);
	    p++;
	}
	putchar('\n');
	//putchar('\n');
}

//
// Print Buffer
//
void pBuf(char *buffer, unsigned int length, unsigned int indent)
{
	int i;

	fprintf(stdout, "\n-----------------------------------------------------------------------\n");

    if (length == 0 || buffer == NULL)
    	return;

    i = 0;
    while (i < length)
    {
        uint8_t array[16];
        int j;

        print_indent(stdout, indent);
        memcpy(array, buffer+i, 16);
        for (j = 0 ; j < 16 && i+j < length; j++)
        {
            fprintf(stdout, "%02X ", array[j]);
            if (j%4 == 3) fprintf(stdout, " ");
        }
        if (length > 16)
        {
            while (j < 16)
            {
                fprintf(stdout, "   ");
                if (j%4 == 3) fprintf(stdout, " ");
                j++;
            }
        }
        fprintf(stdout, " ");
        for (j = 0 ; j < 16 && i+j < length; j++)
        {
            if (isprint(array[j]))
                fprintf(stdout, "%c", array[j]);
            else
                fprintf(stdout, ".");
        }
        fprintf(stdout, " |\n");
        i += 16;
    }

    fprintf(stdout, "-----------------------------------------------------------------------\n");
    putchar('\n');
}

static void print_indent(FILE * stream, int num)
{
    int i;

    for ( i = 0 ; i < num ; i++)
        fprintf(stream, "    ");
}

