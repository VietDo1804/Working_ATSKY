#include "stm32l4xx_ll_bus.h"
#include "stm32l4xx_ll_rcc.h"
#include "stm32l4xx_ll_system.h"
#include "stm32l4xx_ll_utils.h"
#include "stm32l4xx_ll_gpio.h"
#include "stm32l4xx_ll_exti.h"
#include "stm32l4xx_ll_usart.h"
#include "stm32l4xx_ll_pwr.h"
#include "stm32l4xx_ll_lpuart.h"

#include "serial.h"
#include "sys_tick.h"
#include "log.h"

extern void modem_isr(unsigned char c);
__IO uint32_t     ubReceivedChar;

/*************************************************************************
 *
 */
////void LPUART1_IRQHandler(void)
////void USART3_IRQHandler(void)
void USART2_IRQHandler(void)
{
    if(LL_USART_IsActiveFlag_RXNE(USART2))
    {
        // Read Received character. RXNE flag is cleared by reading of RDR register
        ubReceivedChar = LL_LPUART_ReceiveData8(USART2);
        modem_isr(ubReceivedChar);        
    }
    else
    {
        // FE=1 or ORE=1 or NE=1, Framing error / Overrun error / Noise flag
        __IO uint32_t isr_reg;
        isr_reg = LL_USART_ReadReg(USART2, ISR);
        if (isr_reg & LL_USART_ISR_ORE)
        {
            LL_USART_ClearFlag_ORE(USART2);
        }
        else if(isr_reg & LL_USART_ISR_NE)
        {
            LL_USART_ClearFlag_NE(USART2);
        }
        else if(isr_reg & LL_USART_ISR_FE)
        {
            LL_USART_ClearFlag_FE(USART2);
        }
    }    
}

/*************************************************************************
 *
 */
int serial_init(void)
{
    //
    // Setup UART2 port
    //    
    
    //Enable the peripheral clock of GPIO Port
    LL_AHB2_GRP1_EnableClock(LL_AHB2_GRP1_PERIPH_GPIOA);

    // Configure Tx Pin (PA2) as : Alternate function, High Speed, Push pull, Pull up
    LL_GPIO_SetPinMode(GPIOA, LL_GPIO_PIN_2, LL_GPIO_MODE_ALTERNATE);
    LL_GPIO_SetAFPin_0_7(GPIOA, LL_GPIO_PIN_2, LL_GPIO_AF_7);
    LL_GPIO_SetPinSpeed(GPIOA, LL_GPIO_PIN_2, LL_GPIO_SPEED_FREQ_HIGH);
    LL_GPIO_SetPinOutputType(GPIOA, LL_GPIO_PIN_2, LL_GPIO_OUTPUT_PUSHPULL);
    LL_GPIO_SetPinPull(GPIOA, LL_GPIO_PIN_2, LL_GPIO_PULL_UP);

    // Configure Rx Pin (PA3) as : Alternate function, High Speed, Push pull, Pull up
    LL_GPIO_SetPinMode(GPIOA, LL_GPIO_PIN_3, LL_GPIO_MODE_ALTERNATE);
    LL_GPIO_SetAFPin_0_7(GPIOA, LL_GPIO_PIN_3, LL_GPIO_AF_7);
    LL_GPIO_SetPinSpeed(GPIOA, LL_GPIO_PIN_3, LL_GPIO_SPEED_FREQ_HIGH);
    LL_GPIO_SetPinOutputType(GPIOA, LL_GPIO_PIN_3, LL_GPIO_OUTPUT_PUSHPULL);
    LL_GPIO_SetPinPull(GPIOA, LL_GPIO_PIN_3, LL_GPIO_PULL_UP);

    // (2) NVIC Configuration for USART interrupts
    //  - Set priority for USARTx_IRQn
    //  - Enable USARTx_IRQn
    NVIC_SetPriority(USART2_IRQn, 0);  
    NVIC_EnableIRQ(USART2_IRQn);

    // (3) Enable USART peripheral clock and clock source ***********************
    LL_APB1_GRP1_EnableClock(LL_APB1_GRP1_PERIPH_USART2);

    // Set clock source
    LL_RCC_SetUSARTClockSource(LL_RCC_USART2_CLKSOURCE_PCLK1);

    // (4) Configure USART functional parameters ********************************
  
    // Disable USART prior modifying configuration registers
    // Note: Commented as corresponding to Reset value
    // LL_USART_Disable(USARTx_INSTANCE);

    // TX/RX direction
    LL_USART_SetTransferDirection(USART2, LL_USART_DIRECTION_TX_RX);

    // 8 data bit, 1 start bit, 1 stop bit, no parity
    LL_USART_ConfigCharacter(USART2, LL_USART_DATAWIDTH_8B, LL_USART_PARITY_NONE, LL_USART_STOPBITS_2);

    // No Hardware Flow control
    // Reset value is LL_USART_HWCONTROL_NONE
    LL_USART_SetHWFlowCtrl(USART2, LL_USART_HWCONTROL_NONE);

    // Oversampling by 16
    // Reset value is LL_USART_OVERSAMPLING_16
    LL_USART_SetOverSampling(USART2, LL_USART_OVERSAMPLING_16);

    // Set Baudrate to 115200 using APB frequency set to 80000000 Hz
    // Frequency available for USART peripheral can also be calculated through LL RCC macro
    // Ex :
    //  Periphclk = LL_RCC_GetUSARTClockFreq(Instance); or LL_RCC_GetUARTClockFreq(Instance); depending on USART/UART instance
    //  In this example, Peripheral Clock is expected to be equal to 80000000 Hz => equal to SystemCoreClock
    
    LL_USART_SetBaudRate(USART2, SystemCoreClock, LL_USART_OVERSAMPLING_16, 9600); 

    // (5) Enable USART *********************************************************
    LL_USART_Enable(USART2);

    // Polling USART initialisation
    while((!(LL_USART_IsActiveFlag_TEACK(USART2))) || (!(LL_USART_IsActiveFlag_REACK(USART2))))
    { 
    }

    // Enable RXNE and Error interrupts
    LL_USART_EnableIT_RXNE(USART2);
    LL_USART_EnableIT_ERROR(USART2);

	return (1); // success    
    
    
    
    
#if 0    
    //
    // Setup UART3 port
    //    
    
    //Enable the peripheral clock of GPIO Port
    LL_AHB2_GRP1_EnableClock(LL_AHB2_GRP1_PERIPH_GPIOC);

    // Configure Tx Pin (PC10) as : Alternate function, High Speed, Push pull, Pull up
    LL_GPIO_SetPinMode(GPIOC, LL_GPIO_PIN_10, LL_GPIO_MODE_ALTERNATE);
    LL_GPIO_SetAFPin_8_15(GPIOC, LL_GPIO_PIN_10, LL_GPIO_AF_7);
    LL_GPIO_SetPinSpeed(GPIOC, LL_GPIO_PIN_10, LL_GPIO_SPEED_FREQ_HIGH);
    LL_GPIO_SetPinOutputType(GPIOC, LL_GPIO_PIN_10, LL_GPIO_OUTPUT_PUSHPULL);
    LL_GPIO_SetPinPull(GPIOC, LL_GPIO_PIN_10, LL_GPIO_PULL_UP);

    // Configure Rx Pin (PC11) as : Alternate function, High Speed, Push pull, Pull up
    LL_GPIO_SetPinMode(GPIOC, LL_GPIO_PIN_11, LL_GPIO_MODE_ALTERNATE);
    LL_GPIO_SetAFPin_8_15(GPIOC, LL_GPIO_PIN_11, LL_GPIO_AF_7);
    LL_GPIO_SetPinSpeed(GPIOC, LL_GPIO_PIN_11, LL_GPIO_SPEED_FREQ_HIGH);
    LL_GPIO_SetPinOutputType(GPIOC, LL_GPIO_PIN_11, LL_GPIO_OUTPUT_PUSHPULL);
    LL_GPIO_SetPinPull(GPIOC, LL_GPIO_PIN_11, LL_GPIO_PULL_UP);

    // (2) NVIC Configuration for USART interrupts
    //  - Set priority for USARTx_IRQn
    //  - Enable USARTx_IRQn
    NVIC_SetPriority(USART3_IRQn, 0);  
    NVIC_EnableIRQ(USART3_IRQn);

    // (3) Enable USART peripheral clock and clock source ***********************
    LL_APB1_GRP1_EnableClock(LL_APB1_GRP1_PERIPH_USART3);

    // Set clock source
    LL_RCC_SetUSARTClockSource(LL_RCC_USART3_CLKSOURCE_PCLK1);

    // (4) Configure USART functional parameters ********************************
  
    // Disable USART prior modifying configuration registers
    // Note: Commented as corresponding to Reset value
    // LL_USART_Disable(USARTx_INSTANCE);

    // TX/RX direction
    LL_USART_SetTransferDirection(USART3, LL_USART_DIRECTION_TX_RX);

    // 8 data bit, 1 start bit, 1 stop bit, no parity
    LL_USART_ConfigCharacter(USART3, LL_USART_DATAWIDTH_8B, LL_USART_PARITY_NONE, LL_USART_STOPBITS_2);

    // No Hardware Flow control
    // Reset value is LL_USART_HWCONTROL_NONE
    LL_USART_SetHWFlowCtrl(USART3, LL_USART_HWCONTROL_NONE);

    // Oversampling by 16
    // Reset value is LL_USART_OVERSAMPLING_16
    LL_USART_SetOverSampling(USART3, LL_USART_OVERSAMPLING_16);

    // Set Baudrate to 115200 using APB frequency set to 80000000 Hz
    // Frequency available for USART peripheral can also be calculated through LL RCC macro
    // Ex :
    //  Periphclk = LL_RCC_GetUSARTClockFreq(Instance); or LL_RCC_GetUARTClockFreq(Instance); depending on USART/UART instance
    //  In this example, Peripheral Clock is expected to be equal to 80000000 Hz => equal to SystemCoreClock
    
    LL_USART_SetBaudRate(USART3, SystemCoreClock, LL_USART_OVERSAMPLING_16, 9600); 

    // (5) Enable USART *********************************************************
    LL_USART_Enable(USART3);

    // Polling USART initialisation
    while((!(LL_USART_IsActiveFlag_TEACK(USART3))) || (!(LL_USART_IsActiveFlag_REACK(USART3))))
    { 
    }

    // Enable RXNE and Error interrupts
    LL_USART_EnableIT_RXNE(USART3);
    LL_USART_EnableIT_ERROR(USART3);

	return (1); // success
#endif    
}

/*************************************************************************
 *
 */
int serial_deinit(void)
{
	return 0;
}


/*************************************************************************
 *
 */
int serial_send(const char *buf, unsigned int size)
{
    const char *p = buf;
    //int i;
    
    while(size--)
    {
        // Wait for TXE flag to be raised
        while (!LL_LPUART_IsActiveFlag_TXE(USART2))
        {
        }
        
        
        for(int i=0; i<20; i++)
        {
            __nop();
        } // Purposely wait a while for BC68
        
        // Write character in Transmit Data register. TXE flag is cleared by writing data in TDR register
        LL_LPUART_TransmitData8(USART2, *p++);
    }
	return 0;
}

/*************************************************************************
 *
 */
void serial_modem_pwrst(void)
{
#define POWER_EN_PIN    LL_GPIO_PIN_6
#define RESET_N_PIN     LL_GPIO_PIN_5

    // IO init for the modem: POWER_EN, RESET_N
    LL_AHB2_GRP1_EnableClock(LL_AHB2_GRP1_PERIPH_GPIOA);

    // Configure POWER_EN as : GPIO Output, High Speed, PushPull, No-PULL
    LL_GPIO_SetPinMode(GPIOA, POWER_EN_PIN, LL_GPIO_MODE_OUTPUT);
    LL_GPIO_SetPinSpeed(GPIOA, POWER_EN_PIN, LL_GPIO_SPEED_FREQ_HIGH);
    LL_GPIO_SetPinOutputType(GPIOA, POWER_EN_PIN, LL_GPIO_OUTPUT_PUSHPULL);
    LL_GPIO_SetPinPull(GPIOA, POWER_EN_PIN, LL_GPIO_PULL_NO);    
    
    // Configure RESET_N as : GPIO Output, High Speed, PushPull, No-PULL
    LL_GPIO_SetPinMode(GPIOA, RESET_N_PIN, LL_GPIO_MODE_OUTPUT);
    LL_GPIO_SetPinSpeed(GPIOA, RESET_N_PIN, LL_GPIO_SPEED_FREQ_HIGH);
    LL_GPIO_SetPinOutputType(GPIOA, RESET_N_PIN, LL_GPIO_OUTPUT_PUSHPULL);
    LL_GPIO_SetPinPull(GPIOA, RESET_N_PIN, LL_GPIO_PULL_NO);
    
    // Power up the modem
    LL_GPIO_SetOutputPin(GPIOA, POWER_EN_PIN);
    msleep(800);    // BC66 need > 500ms
    LL_GPIO_ResetOutputPin(GPIOA, POWER_EN_PIN);
    
    // Reset the modem
    LL_GPIO_SetOutputPin(GPIOA, RESET_N_PIN);
    msleep(80);    // BC66 need > 50ms
    LL_GPIO_ResetOutputPin(GPIOA, RESET_N_PIN);    
        
    msleep(2000);
}

